/* Functionality to represent an RGB LED connected to an Arduino pin
 *
 * Copyright (c) 2021 Adam Wagman
 *
 * This code is in the public domain.
 */

#ifndef hr_rgb_led_h
#define hr_rgb_led_h

namespace HR
{
  class RgbLED
  {
   public:
   RgbLED(int pinRed, int pinGreen, int pinBlue):
     pinRed_(pinRed),
     pinGreen_(pinGreen),
     pinBlue_(pinBlue)
     {
       pinMode(pinRed_, OUTPUT);
       pinMode(pinGreen_, OUTPUT);
       pinMode(pinBlue_, OUTPUT);
       
       turnOff();
     }
     
    void turnOff() { setRgb(0, 0, 0); }
    
    // Set the brightness of the LED by specifying the
    // brightness of each color, in the range [0, 1].
    void setRgb(float red, float green, float blue)
    {
      setPin_(pinRed_, red);
      setPin_(pinGreen_, green);
      setPin_(pinBlue_, blue);
    }
  
  private:
    void setPin_(int pin, float value)
    {
      // We want to convert from floating-point [0,1] to integer [0, 255].
      // We'll make sure to clamp the value in case the user gives us
      // something outside the legal [0, 1] range.
    
      int analogValue;
      if (value <= 0)
        analogValue = 0;
      else if (value >= 1)
        analogValue = 255;
      else
        analogValue = (int)(255 * value + 0.5); // Adding 0.5 rounds
       
#ifdef VERBOSE       
      Serial.print("Pin ");
      Serial.print(pin);
      Serial.print("  value: ");
      Serial.println(analogValue);
#endif

      analogWrite(pin, analogValue); 
    }
  
    int pinRed_;
    int pinGreen_;
    int pinBlue_;
  };

} // end namespace

#endif // include guard
