This demo uses an HC-SR04 distance sensor and an RGB LED.  The LED will turn red if
the sensor measures something very close, and it will turn green if the sensor measures
something very far away.

Components needed
------------------
  Arduino board
  breadboard
  HC-SR04 ultrasonic distance sensor
  RGB LED (when off, the LED looks white, and it has 4 leads)
  3 resistors (any small value will do, e.g., 220 ohm)
  wires (approx 10)
  
Wiring
----------
Breadboard:
  Arduino +5V to + rail on breadboard
  Arduino GND to - rail on breadboard
  
  
HC-SR04:
  Vcc to + rail on breadboard
  Gnd to - rail on breadboard
  Trig to pin 5
  Echo to pin 6
  
RGB LED:
  The RGB has 4 leads.  The long one is the ground lead.  Going outward from the
  long lead, the single lead is for red, the closer lead on the side with two leads
  is green, and the farther lead on the side with two leads is blue.
  
  long lead to - rail on breadboard (no resistor needed)
  red to resistor #1, and then other end of resistor #1 to pin 8 (typically via breadboard first)
  green to resistor #2, and then other end of resistor #2 to pin 9 (typically via breadboard first)
  blue to resistor #3, and then other end of resistor #3 to pin 10 (typically via breadboard first)
  