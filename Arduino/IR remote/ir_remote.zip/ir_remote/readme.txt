This demo uses an IR remote.  The serial monitor is used to print out what button
was pushed.

IMPORTANT
----------
There are a number of versions of the IRRemote library, and this example was
specifically written to use version 2.7.0.  Sometimes the Arduino web editor
will not respect the version selected via the Library Manager, so you'll probably
need to install the 2.7.0 version of IRRemote library from the following location.
   https://www.arduino.cc/reference/en/libraries/irremote/
Download the library and then use the "Import" button on the Libraries tab.


Components needed
------------------
  Arduino board
  breadboard
  IR receiver module
  IR remote
  wires (approx 5)
  
Wiring
----------
Breadboard:
  Arduino +5V to + rail on breadboard
  Arduino GND to - rail on breadboard
  
IR receiver module:
  R to + rail on breadboard
  G to - rail on breadboard
  Y to pin 2
