/* Functionality to represent an LED connected to an Arduino pin
 *
 * Copyright (c) Adam Wagman
 *
 * This code is in the public domain.
 */
 
#ifndef AW_LED_H
#define AW_LED_H

namespace AW
{

class LED
{
public:
  LED(int pin, bool isOn);
  // Construct an LED object for an LED connected to the specified pin.
  // If <isOn> is true, turn the LED on; otherwise, turn the LED off.
  
  bool isOn() const;
  // Returns whether the LED is currently on or not.

  void turnOff();
  // Turns off the LED.
  
  void turnOn();
  // Turns on the LED.
  
  void toggle();
  // If the LED is on, turns off the LED; if the LED is off, turn on the
  // LED.
  
  void startBlink(int blinkPeriodMsec);
  // Start blinking, using the specified period; the LED will be on for half
  // the period and off for half the period.
  //
  // In order for blinking to actually occur, the user must call
  // checkEvents() occasionally; a blink action will take effect when
  // checkEvents() is called at least half the blink period from the last
  // blink.
  //
  // Blinking will continue until stopBlink(), turnOff(), turnOn(), or
  // toggle() is called.
  
  void stopBlink();
  // Stop any further blinking; the LED will remain in its current on or off
  // state.  There is no effect if the LED isn't currently blinking.
  
  void checkEvents();
  // Check to see whether it's time to do a blink, if startBlink() has been
  // called and not stopped yet. If it isn't time yet, do nothing.
  
private:
  int           pin_;
  bool          isOn_;
  bool          isBlinkEnabled_;
  int           blinkPeriodMsec_;
  unsigned long blinkTriggerTimeMsec_;
};

} // end of namespace

#endif