/* Functionality to represent an LED connected to an Arduino pin
 *
 * Copyright (c) Adam Wagman
 *
 * This code is in the public domain.
 */
 
#include "LED.h"

// The header file "Arduino.h" is needed to use things like LOW, HIGH,
// and digitalWrite(); it is automatically included in a sketch but not in a
// library.
#include "Arduino.h"

AW::LED::LED(int pin, bool isOn)
{
  // Note: We really should check whether the input values are all
  //       reasonable (e.g., that the value of <pin> is positive), but
  //       we'll ignore error checking for now.
  
  pin_                   = pin;
  isOn_                  = isOn;
  isBlinkEnabled_        = false;
  blinkTriggerTimeMsec_  = 0;
  blinkPeriodMsec_       = 0;
  

  // Initialize the specified digital pin as an output.
  pinMode(pin, OUTPUT);
  
  // Now we need to actually turn the LED on or off.
  if (isOn)
    turnOn();
  else
    turnOff();  
}

void AW::LED::turnOn()
{
  // Stop blinking, if blinking is active.  
  stopBlink();
  
  // Turn the LED on by setting the voltage on the pin to the high voltage
  // value, which is typically +5V. (Read "plus 5 volts".)
  //
  // Note:
  //   "HIGH" is a constant already defined by the Arduino Programming
  //   Language itself.
  
  digitalWrite(pin_, HIGH);

  isOn_ = true;
}

void AW::LED::turnOff()
{
  // Stop blinking, if blinking is active.  
  stopBlink();
  
  // Turn the LED off by setting the voltage on the pin to the low
  // voltage value, which is 0V. (Read "0 volts".)
  //
  // Note:
  //   "LOW" is a constant already defined by the Arduino Programming
  //   Language itself.
  digitalWrite(pin_, LOW);
  
  isOn_ = false;
}

void AW::LED::toggle()
{
  if (isOn_)
    turnOff();
  else
    turnOn();
}

void AW::LED::startBlink(int blinkPeriodMsec)
{
  // Stop any previous blink.
  stopBlink();
  
  // At the start of the blink, we immediately toggle.
  toggle();
  
  // Keep track of when a call to checkEvents() should toggle again.
  isBlinkEnabled_       = true;
  blinkPeriodMsec_      = blinkPeriodMsec;
  blinkTriggerTimeMsec_ = millis() + blinkPeriodMsec / 2;
}

void AW::LED::stopBlink()
{
  isBlinkEnabled_       = false;
  blinkPeriodMsec_      = 0;
  blinkTriggerTimeMsec_ = 0;
}

void AW::LED::checkEvents()
{
  // If blinking is enabled, check the current time and see if
  // we've reached the time to toggle.
  
  if (isBlinkEnabled_)
  {
    unsigned long timeNowMsec = millis();
    
    if (timeNowMsec >= blinkTriggerTimeMsec_)
    {
      // We need to call toggle().  Since toggle() by itself clears out
      // the blinking information, we make a copy of the period first.
      int blinkPeriodMsec = blinkPeriodMsec_;
      
      toggle();
      
      // Now set up for the next toggle.
      isBlinkEnabled_       = true;
      blinkPeriodMsec_      = blinkPeriodMsec;
      blinkTriggerTimeMsec_ = millis() + blinkPeriodMsec / 2;
    }
  }
}
